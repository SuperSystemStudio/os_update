from setuptools import setup
setup(
    name='osupdate', 
    description='string to date', 
    url='https://github.com/SuperSystemStudio/os_update', 
    author='Mryan', 
    author_email='A2564011261@163.com', 
    license='Apache-2.0'
)