from setuptools import setup
setup(
    name='osinfo', 
    version='1.1',
    description='It inherits OS adds info prompts', 
    url='https://github.com/SuperSystemStudio/os_update', 
    author='Mryan', 
    author_email='A2564011261@163.com', 
    license='Apache-2.0'
)